'use strict';

/**
 * @param {Egg.EggAppInfo} appInfo app info
 */
module.exports = appInfo => {
  /**
   * built-in config
   * @type {Egg.EggAppConfig}
   **/
  const config = exports = {};

  // 数据库配置
  config.sequelize = {
    dialect: 'mysql',
    database: 'blog',
    host: '127.0.0.1',
    port: '3306',
    username: 'root',
    password: 'liuxingyu',
    timezone: '+08:00'
  }

  config.qiniu = {
    accessKey: 'tnQB9kYVCKf0kxK0IGxun6p5aFORw3plufdw-qvQ',
    secretKey: 'pA213rIyyY8fvbjWVm3NZntUmJ4eemqTKVpNomy7',
  }

  return {
    ...config,
  };
};