// This file is created by egg-ts-helper@1.25.9
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportArticle = require('../../../app/controller/article');
import ExportComment = require('../../../app/controller/comment');
import ExportHome = require('../../../app/controller/home');
import ExportTest = require('../../../app/controller/test');
import ExportUser = require('../../../app/controller/user');

declare module 'egg' {
  interface IController {
    article: ExportArticle;
    comment: ExportComment;
    home: ExportHome;
    test: ExportTest;
    user: ExportUser;
  }
}
